//
//  SentMemeTableViewController.swift
//  MemeV1.0
//
//  Created by Rob and Megan Low on 10/9/19.
//  Copyright © 2019 R&M. All rights reserved.
//

import UIKit
import Foundation


class SentMemeTableViewController: UITableViewController, UINavigationControllerDelegate {
    
    let cellReuseIdentifier = "SentMemeTableViewCell"
    var memes = MemeArchiver.getImages()
    
    override func viewDidLoad() {
           super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        self.memes = MemeArchiver.getImages()
        tableView.reloadData()
    }
  
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.memes.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell =  tableView.dequeueReusableCell(withIdentifier: self.cellReuseIdentifier)!
        cell.imageView?.image = memes[indexPath.row]

        return cell

    }
}

