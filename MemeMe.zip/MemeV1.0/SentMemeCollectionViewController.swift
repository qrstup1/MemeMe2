//
//  SentMemeCollectionViewController.swift
//  MemeV1.0
//
//  Created by Rob and Megan Low on 10/9/19.
//  Copyright © 2019 R&M. All rights reserved.
//

import UIKit
import Foundation

class SentMemeCollectionViewController: UICollectionViewController, UINavigationControllerDelegate {
    
    @IBOutlet weak var flowLayout: UICollectionViewFlowLayout!
    
    var memes = MemeArchiver.getImages()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let space:CGFloat = 3.0
        let dimension = (self.collectionView.frame.size.width - (2 * space))/3.0
        flowLayout.minimumInteritemSpacing = space
        flowLayout.minimumLineSpacing = space
        flowLayout.itemSize = CGSize(width: dimension, height: dimension)
        print(dimension)
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.memes = MemeArchiver.getImages()
        collectionView.reloadData()
        print(self.flowLayout.itemSize)
    }
   
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.memes.count
    }
    
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionViewcell", for: indexPath) as! SentMemeCollectionViewCell
        
        cell.image?.image = memes[indexPath.item]
  //      cell.text.text = "TEXT LABEL"
        return cell
    }
    
}
/*
override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VillainCollectionViewCell", for: indexPath) as! VillainCollectionViewCell
    let villain = self.allVillains[(indexPath as NSIndexPath).row]

    // Set the name and image
    cell.nameLabel.text = villain.name
    cell.villainImageView?.image = UIImage(named: villain.imageName)

    return cell
}

*/

