//
//  ViewController.swift
//  MemeV1.0
//
//  Created by RL on 9/14/19.
//  Copyright © 2019 R&M. All rights reserved.
//
//Dear code reviewer. Thank you for taking the time to review my code. I look forward to the feedback, and the different perspective you have.


import UIKit

class MemeEditorViewController: UIViewController, UIImagePickerControllerDelegate,
UINavigationControllerDelegate, UITextFieldDelegate  {
    
    @IBOutlet weak var bottomTextField: UITextField!
    @IBOutlet weak var topText: UITextField!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var albumSelectionButton: UIBarButtonItem!
    @IBOutlet weak var photoSelectionButton: UIBarButtonItem!
    @IBOutlet weak var shareButton: UIBarButtonItem!
    @IBOutlet weak var cancelButton: UIBarButtonItem!
    @IBOutlet weak var topNavBar: UINavigationBar!
    @IBOutlet weak var bottomToolBar: UIToolbar!
    
    
    override func viewDidLoad() {
        //Function creates the initial deviations and setup characteristics for the text fields and pickers.
        super.viewDidLoad()
        setTextFieldAttributes(textField: topText, text: "TOP")
        setTextFieldAttributes(textField: bottomTextField, text: "BOTTOM")
        shareButton.isEnabled = false
    }
    
    func setTextFieldAttributes (textField: UITextField, text: String) {
        //Sets the default text field attributes associated with the MEME... This does not impact the initial placeholder font.
        
        textField.defaultTextAttributes = [
            .font: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
            .foregroundColor: UIColor.white,
            .strokeColor: UIColor.black,
            .strokeWidth: -5.0
        ]
        textField.textAlignment = NSTextAlignment.center
        textField.text = text
        textField.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //subscribes to the keyboard notification when the view will appear.
        
        photoSelectionButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        super.viewWillAppear(animated)
        subscribeToKeyboardNotifications()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        //Function unsubscribes from monitoring when the view will disappear.
        
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
    }
    
    func subscribeToKeyboardNotifications() {
        //Function subscribes to the keyboard notifications.
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications() {
        //function tracks for unsubscribing to the keyboard notifications.
        
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @IBAction func shareAction(_ sender: Any) {
        //Function handles the activityViewController for showing the sharing menue and directing the generation and saving of the memed image.
        
        let image = generateMemedImage()
        let controller = UIActivityViewController(activityItems: [image], applicationActivities: nil)
        
        controller.completionWithItemsHandler = { (activityType: UIActivity.ActivityType?, completed: Bool, returnedItems: [Any]?, activityErrors: Error?) -> Void in
            if completed {
                self.save(memeImage: image)
            }
        }
        self.present(controller, animated: true, completion: nil)
    }
    
    @IBAction func cancelAction(_ sender: Any) {
        //This function creates the reset features for the cancel button. Esentially clearing the created MEME and starting over without resetting the app.
        
        imageView.image = nil
        bottomTextField.text = ""
        topText.text = ""
        bottomTextField.placeholder = "BOTTOM"
        topText.placeholder = "TOP"
        shareButton.isEnabled = false
    }
    
    
    @objc func keyboardWillShow(_ notification:Notification) {
        //This function determines if the top or bottom text field is active and shifts the view appropriately
        
        if bottomTextField.isEditing {
            view.frame.origin.y = -getKeyboardHeight(notification)
        }
        else if topText.isEditing {
        }
    }
    
    @objc func keyboardWillHide(_ notification:Notification) {
        //This function resets the origin of the view to the original 0 point.
        view.frame.origin.y = 0
    }
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        // Function provides the keyboard height in the form of a Float to allow for adjusting the display the appropriate number to keep the bottom text on the screen.
        
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }
    //I am here working on the tagging functionality of this code. Both the album and file are now linked to this action item. with selerate outlets above.
    
    @IBAction func photoSelection(sender: UIBarButtonItem) {
        switch sender {
        case photoSelectionButton: imageSelector(type: "camera")
        case albumSelectionButton: imageSelector(type: "photoLibrary")
        default: print("Button Selection Not Found")
            break
        }
    }
    func imageSelector(type: String) {
        //Based on the source of the image being selected, this function executes the selection and manages assiging the source type to present the appropriate selection.
        
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        if type == "camera"{
            imagePicker.sourceType = .camera}
        else if type == "photoLibrary" {
            imagePicker.sourceType = .photoLibrary}
        present(imagePicker, animated: true, completion: nil)
        shareButton.isEnabled = true
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        //This function assigns the selected image to the ImageView
        
        if let image = info[.originalImage] as? UIImage {
            imageView.image = image
            self.dismiss(animated: true, completion: nil)
        }
        else { self.dismiss(animated: true, completion: nil)}
    }
    
    func generateMemedImage() -> UIImage {
        //This function creates an image from the meme without the Nav and tool bar's showing. It returns the image alone to the called position as a UIImage
        
        hideBars(hide: true)
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        hideBars(hide: false)
        return memedImage
    }
    
    func hideBars(hide: Bool) {
        //This function is only to minimie redundant code for allowing for hiding and showing the nav and tool bar based on a passed bool value.
        bottomToolBar.isHidden = hide
        topNavBar.isHidden = hide
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //At the begining of editing text fields this function clears the placeholder and text being stored in the textField. Clearing the placeholder allows the user to display no text if desired on either the top or bottom.
        
        textField.placeholder = ""
        textField.text = ""
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //This function allows the user to touch in the display to minimize the keyboard.
        
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //Function allows the minimizing of the keyboard when the return button is pressed.
        
        textField.resignFirstResponder()
        return true
    }
    func save(memeImage: UIImage) {
        
        //The following code is written to safe the meme created to the Class MemeArchiver, in a future version I expect to replace the _ with a name to allow for recalling. The meme archiver upon initialization parses the image out to storage for use in tables and collections. 
        
        _ = MemeArchiver(topText: self.topText.text!, bottomText: self.bottomTextField.text!, originalImage: self.imageView.image!, memedImage: memeImage)
        print("save Complete")
        let memes = MemeArchiver.getImages()
        print(memes.count)

    }
}


