//
//  MemeArchiver.swift
//  MemeV1.0
//
//  Created by RL on 10/1/19.
//  Copyright © 2019 R&M. All rights reserved.
//

import Foundation
import UIKit

class MemeArchiver{
    struct Meme {
        var topText: String
        var bottomText: String
        var originalImage: UIImage
        var memedImage: UIImage
    }
    init(topText: String, bottomText: String, originalImage: UIImage, memedImage: UIImage) {
        _ = Meme(topText: topText, bottomText: bottomText, originalImage: originalImage, memedImage:  memedImage)
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        appDelegate.memes.append(memedImage)
    }
   class func getImages() -> [UIImage] {
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.memes
    }

}
