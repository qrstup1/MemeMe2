//
//  SentMemeCollectionViewCell.swift
//  MemeV1.0
//
//  Created by Rob and Megan Low on 10/18/19.
//  Copyright © 2019 R&M. All rights reserved.
//

import UIKit

class SentMemeCollectionViewCell: UICollectionViewCell {
   
    @IBOutlet var image: UIImageView!
 //   @IBOutlet var text: UILabel!
    
}
